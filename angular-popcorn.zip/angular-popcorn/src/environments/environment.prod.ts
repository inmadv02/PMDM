export const environment = {
  production: true,
  apiBaseUrl: 'https://api.themoviedb.org/3',
  apiKey: '1c0ce60ed8e0cd9f90ffb9b539b4c646', // Debo introducir mi API KEY de desarrollador que he obtenido en la web de TheMovieDB API.
  defaultLang: 'es-ES',
  imageBaseUrl: 'https://image.tmdb.org/t/p/w500'
};
