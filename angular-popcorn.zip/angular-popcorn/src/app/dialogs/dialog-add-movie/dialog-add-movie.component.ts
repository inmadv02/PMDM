import { Component, Inject, OnInit } from '@angular/core';
import { MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Movie } from 'src/app/models/interfaces/movies-popular.interface';
import { MoviesService } from 'src/app/services/movies.service';
import { environment } from 'src/environments/environment';

export interface DialogAddMovieComponent{
  id: number;
}

@Component({
  selector: 'app-dialog-add-movie',
  templateUrl: './dialog-add-movie.component.html',
  styleUrls: ['./dialog-add-movie.component.css']
})
export class DialogAddMovieComponent implements OnInit {

  movie!: Movie;

  constructor(@Inject(MAT_DIALOG_DATA) private data : DialogAddMovieComponent,
  private moviesService: MoviesService) { }

  ngOnInit(): void {
    this.moviesService.getMovieById(this.data.id).subscribe(result => {
      this.movie = result;
    });

     
  }

  getMovieImageUrl(movie: Movie) {
    return `${environment.imageBaseUrl}${movie.poster_path}`;
  }

}
