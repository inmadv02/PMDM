import { Component, OnInit } from '@angular/core';
import { Planet } from 'src/app/models/interfaces/planets.interface';
import { PlanetsService } from 'src/app/services/planets.service';

@Component({
  selector: 'app-planets-list',
  templateUrl: './planets-list.component.html',
  styleUrls: ['./planets-list.component.css']
})
export class PlanetsListComponent implements OnInit {

  planetList : Planet[] = [];

  constructor(private planetService : PlanetsService) { }

  ngOnInit(): void {
    this.planetService.getPlanetList().subscribe(planetsResponse => {
      this.planetList = planetsResponse.results});
  }

}
