import { Component, OnInit } from '@angular/core';
import { Person, PeopleResponseList, Gender } from 'src/app/models/interfaces/people.interface';
import { PeopleService } from 'src/app/services/people.service';

@Component({
  selector: 'app-people-list',
  templateUrl: './people-list.component.html',
  styleUrls: ['./people-list.component.css']
})
export class PeopleListComponent implements OnInit {

  peopleList : Person[] = [];
  newPeopleList : Person[] = [];
  genero!: Gender;
  generos: Gender[] = [];

  constructor(private peopleService : PeopleService) { }

  ngOnInit(): void {
    this.peopleService.getPeopleList().subscribe(peopleResponse => {
      this.peopleList = peopleResponse.results});
  }

  filterCharactersByGender(){
    this.newPeopleList = this.peopleList;

    this.newPeopleList = this.peopleList.filter(filtrado => filtrado.gender.includes(this.genero));
  }

  noFilter() {
    this.newPeopleList = this.peopleList;

  }

}
