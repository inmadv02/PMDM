import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { PlanetsService } from 'src/app/services/planets.service';

@Component({
  selector: 'app-planet-detail',
  templateUrl: './planet-detail.component.html',
  styleUrls: ['./planet-detail.component.css']
})
export class PlanetDetailComponent implements OnInit {

  id!: string;

  constructor(private activeRoute: ActivatedRoute, private planetService : PlanetsService) { }

  ngOnInit(): void {
    this.activeRoute.params.subscribe(parametros => { this.id = parametros['idPlanet'];
    this.planetService
  });
    
  }


 
}
