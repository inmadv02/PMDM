import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Person } from 'src/app/models/interfaces/people.interface';
import { PersonResponse } from 'src/app/models/interfaces/person.interface';
import { PeopleService } from 'src/app/services/people.service';

@Component({
  selector: 'app-person-detail',
  templateUrl: './person-detail.component.html',
  styleUrls: ['./person-detail.component.css']
})
export class PersonDetailComponent implements OnInit {
  id!: string;
  person!: PersonResponse;

  constructor(private activeRoute: ActivatedRoute,
    private peopleService: PeopleService) { }

  ngOnInit(): void {
    this.activeRoute.params.subscribe(identificador => {
      this.id = identificador['idPerson'];
      this.peopleService.getPersonById(this.id).subscribe(persona => {
        this.person = persona;
      });
    });

  }

}