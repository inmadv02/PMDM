import { Input } from '@angular/core';
import { Component, OnInit } from '@angular/core';
import { Person, PeopleResponseList } from 'src/app/models/interfaces/people.interface';

@Component({
  selector: 'app-person-item',
  templateUrl: './person-item.component.html',
  styleUrls: ['./person-item.component.css']
})
export class PersonItemComponent implements OnInit {

  @Input() peopleInput!: Person;

  constructor() { }

  ngOnInit(): void {
  }

  getPersonImageUrl(person: Person) {
    return `${person.url}`;
  }

}
