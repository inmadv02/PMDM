import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PersonDetailComponent } from './components/person-detail/person-detail.component';
import { PeopleListComponent } from './pages/people-list/people-list.component';
import { PlanetsListComponent } from './pages/planets-list/planets-list.component';

const routes: Routes = [
  { path:'people', component: PeopleListComponent },
  { path:'planets', component: PlanetsListComponent },
  { path:'people/:idPerson', component: PersonDetailComponent },
  { path: '', pathMatch: 'full', redirectTo: '/people' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
