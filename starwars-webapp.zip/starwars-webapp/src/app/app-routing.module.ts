import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PeopleListComponent } from './pages/people-list/people-list.component';
import { PlanetsListComponent } from './pages/planets-list/planets-list.component';

const routes: Routes = [
  { path:'people', component: PeopleListComponent },
  { path:'planets', component: PlanetsListComponent },
  { path: '', pathMatch: 'full', redirectTo: '/people' }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
