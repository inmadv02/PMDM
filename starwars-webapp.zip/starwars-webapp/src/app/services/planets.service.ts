import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { PeopleResponseList } from "../models/interfaces/people.interface";
import { environment } from "src/environments/environment";
import { PlanetsListResponse } from "../models/interfaces/planets.interface";

const API_BASE_URL = `${environment.apiBaseUrl}`;

@Injectable({
  providedIn: 'root'
})
export class PlanetsService {

  constructor(private http : HttpClient) { }

  getPlanetList() : Observable<PlanetsListResponse> {
    return this.http.get<PlanetsListResponse>(`${API_BASE_URL}/planets`);
  }
}
