import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { PeopleResponseList } from "../models/interfaces/people.interface";
import { environment } from "src/environments/environment";
import { PersonResponse } from "../models/interfaces/person.interface";

const API_BASE_URL = `${environment.apiBaseUrl}`;

@Injectable({
  providedIn: 'root'
})
export class PeopleService {

  constructor(private http : HttpClient) { }

  getPeopleList() : Observable<PeopleResponseList> {
    return this.http.get<PeopleResponseList>(`${API_BASE_URL}/people`);
  }

  getPersonById(id : string): Observable<PersonResponse> {
    return this.http.get<PersonResponse>(`${API_BASE_URL}/people/${id}`);
  }
}
